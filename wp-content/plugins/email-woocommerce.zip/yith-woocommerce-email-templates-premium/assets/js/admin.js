jQuery( function ( $ ) {
    $( '.yith-wcet-select2' ).select2();
} );