<div style="width: 100%;float:left; margin-bottom:0px;">
        <p style="text-align:right;width: 100%;"><?php echo __('WooCommerce PDF Invoices, Packing Slips, Delivery Notes & Shipping Labels (Basic) | Developed by','print-invoices-packing-slip-labels-for-woocommerce'); ?></p>
        <img src="<?php echo esc_url(WF_PKLIST_PLUGIN_URL.'assets/images/webtoffee-logo_small.png'); ?>" style="float: right;">
</div>