<?php
$arr=array(
	'create_new_template'=>__('Click to view predefined templates.','print-invoices-packing-slip-labels-for-woocommerce'),
	'dropdown_menu'=>__('Create a new template or edit an existing template.','print-invoices-packing-slip-labels-for-woocommerce'),
	'design_view'=>__('Displays the currently chosen document template with provisions to modify.','print-invoices-packing-slip-labels-for-woocommerce'),
	'preview_option'=>__('Shows a preview of the template on an actual order. Key in an order number to view the same.','print-invoices-packing-slip-labels-for-woocommerce'),
);