<?php
$template_arr=array(
	array(
		'id'=>'template1',
		'title'=>__('Classic', 'print-invoices-packing-slip-labels-for-woocommerce'),
		'preview_img'=>'template1.png',
	),
);