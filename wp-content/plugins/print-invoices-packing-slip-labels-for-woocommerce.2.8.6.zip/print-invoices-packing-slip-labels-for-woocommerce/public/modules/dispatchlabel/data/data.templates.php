<?php
$template_arr=array(
	array(
		'id'=>'template1',
		'title'=>__('Dispatch Label 1', 'print-invoices-packing-slip-labels-for-woocommerce'),
		'preview_img'=>'template1.png',
	),
);