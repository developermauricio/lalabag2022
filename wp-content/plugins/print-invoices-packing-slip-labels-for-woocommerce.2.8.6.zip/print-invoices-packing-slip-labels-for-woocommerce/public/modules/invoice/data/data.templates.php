<?php
$template_arr=array(
	array(
		'id'=>'template5',
		'title'=>__('Classic', 'print-invoices-packing-slip-labels-for-woocommerce'),
		'preview_img'=>'template5.png',
	),
	array(
		'id'=>'template4',
		'title'=>__('Standard', 'print-invoices-packing-slip-labels-for-woocommerce'),
		'preview_img'=>'template4.png',
	),
);