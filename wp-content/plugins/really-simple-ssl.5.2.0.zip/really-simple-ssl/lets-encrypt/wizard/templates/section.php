<div class="rsssl-section {active} {completed}">
    {icon}
    <a href="{url}">
		<h3>{title}</h3>
	</a>
</div>
