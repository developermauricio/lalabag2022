=== Paid Memberships Pro - WooCommerce Add On ===
Contributors: strangerstudios
Tags: pmpro, paid memberships pro, woocommerce, member, prices, pricing, membership, subscription
Requires at least: 5.0
Tested up to: 5.8
Stable tag: 1.7.3

Integrates Paid Memberships Pro with WooCommerce to sell Membership as a product and set members-only product discounts.

== Description ==

Integrates Paid Memberships Pro with WooCommerce to sell Memberships as a product, set a global % discount on products by level, or set a per-product members-only price.

= Several Key Features Including =

* Sell a Membership in Paid Memberships Pro as a WooCommerce Product (WooCommerce Subscriptions required for recurring subscriptions).
* Set Custom Product Pricing based on Membership Level.
* Set a Global Percentage Discount for All Products Based on Membership Level.
* Works with WooCommerce Subscriptions Premium Add On for WooCommerce.
* Works with the Multiple Memberships Per User Add On for Paid Memberships Pro.
* Synchronizes the Billing Address Fields Between WooCommerce and Paid Memberships Pro.

[Watch the tutorial video to learn more](https://www.paidmembershipspro.com/add-ons/pmpro-woocommerce/).

= Official Paid Memberships Pro Add On =

This is an official Add On for [Paid Memberships Pro](https://www.paidmembershipspro.com), the most complete member management and membership subscriptions plugin for WordPress.

== Installation ==

1. Upload the `pmpro-woocommerce` directory to the `/wp-content/plugins/` directory of your site.
2. Activate the plugin through the `Plugins` menu in WordPress.

Or install directly from the Plugin Repository using the Plugins system in WordPress.

= Create a Membership Product =
1. Edit a product or add a new product.
2. Select the "Membership" tab in the "Product Data" metabox.
3. Select a level from the "Membership Product" dropdown.
4. Save changes.

= Set Member Discount Pricing" on a Product =
1. Edit a product or add a new product.
2. Select the "Membership" tab in the "Product Data" metabox.
3. Set a price for one or more levels in the "Member Discount Pricing" section.
4. Save changes.

= Set a Global Shop Discount for Members =
1. Edit a membership level under Membership > Settings.
2. Locate the "Set Membership Discount" section.
3. Add a percent discount to the field.
4. Save changes.

== Frequently Asked Questions ==

= I found a bug in the plugin. =

Please post it in the issues section of GitHub and we'll fix it as soon as we can. Thanks for helping. https://github.com/strangerstudios/pmpro-woocommerce/issues

== Screenshots ==

1. The "Membership" meta box on a single product. Optionally use this WooCommerce Product to buy a PMPro Membership Level or set specific pricing based on membership level for each product.
2. The "Set Membership Discount" field on the "Edit Membership Level" page (Memberships > Settings > Membership Levels > Edit).

== Changelog ==
= 1.7.3 - 2021-08-25 =
* ENHANCEMENT: Tested up to WooCommerce 5.6.0.
* ENHANCEMENT: Added support for time in expiration dates when extending or renewing a level and checking out for a new membership level.
* BUG FIX: Fixed an issue where variation prices would show twice if the min and max price was identical. (Thanks, ArdiNEC on GitHub)
* BUG FIX: Fixed an issue of a non-numeric warning value when discount was empty.
* BUG FIX: Fixed deprecated function warnings.

= 1.7.2 - 2021-03-13 =
* ENHANCEMENT: Tested up to WooCommerce 5.1.0.
* ENHANCEMENT: Added .pot file and British English po/mo files.
* BUG FIX: Fixed issue where memberships associated with subscriptions in pending-cancel status were cancelled. We now wait for the full canceled status.
* BUG FIX: When variable products are used, we will look for a membership price on the parent product. No support for member prices on variations yet.
* BUG FIX: Removed use of deprecated $order->get_product_from_item() method. (Thanks, ogiebobogh on GitHub)

= 1.7.1 - 2021-01-13 =
* BUG FIX: Fixed issue where discount for membership products would be applied when shouldn't.
* ENHANCEMENT: Improved wording on the Advanced Settings area for Membership and WooCommerce Subscriptions discount option.

= 1.7 - 2020-05-01 =
* BUG FIX: Fixed bug where marking an order expired or cancelled could impact other subscriptions.
* BUG FIX: Fixed typo with `woocommerce_order_status_on-hold`.
* BUG FIX: Fixed bug that kept the "Apply Member Discounts to WC Subscription Products?" setting (under Memberships -> Settings -> Advanced) from working properly.
* BUG FIX/ENHANCEMENT: Checked that $product is actually a `product` post_type when checking if user has active membership for level.
* BUG FIX/ENHANCEMENT: Improved checks for cancelling membership if membership product expires.
* ENHANCEMENT: Added function `pmprowoo_user_has_active_membership_product_for_level` to return whether a user has an active WooCommerce product that gives membership.
* ENHANCEMENT: Updated tested up to value for WooCommerce to v4.0 and WordPress to v5.4

= 1.6.1 - 2018-06-25 =
* BUG FIX: Fixed fatal error in pmprowoo_get_membership_products_from_order() that was happening on some systems.
* ENHANCEMENT: Localization/GlotPress support.

= 1.6 - 2018-06-19 =
* BUG FIX: Fixed bug when deselecting the autocomplete option on a membership product.
* BUG FIX: Now checking if a user has a different subscription linked to their membership level before removing a user's membership level. Users switching between subscriptions for the same level would have their level removed. (Thanks, Ted Barnett)
* BUG FIX: Fixed issues when a product with a sale price also has membership pricing.
* BUG FIX/ENHANCEMENT: Updated to work with the latest versions of WooCommerce (3.4.2) and WooCommerce Subscriptions (2.2.22).
* ENHANCEMENT: Added a filter pmprowoo_get_membership_price, which can be used to support variable products via custom code (like this https://gist.github.com/ideadude/5c7ed35a50087178a47d92b192933614)
* ENHANCEMENT: Added support for PMPro Multiple Memberships per User.

= 1.5 =
* BUG/FIX: Various PHP Warning messages (Deprecated functionality)
* ENHANCEMENT: Prevents a user from adding more than a single membership product to the shopping cart
* ENHANCEMENT: Improved function documentation by adding the "WC requires at least" and "WC tested up to" fields to the plugin header.

= 1.4.5 =
* BUG: Fixed issue where since WC v3.0 variable products were not having their prices adjusted properly based on the membership pricing settings.

= 1.4.4 =
* BUG: No longer cancelling out other fields set via the pmpro_custom_advanced_settings filter. (Thanks, Nurul Umbhiya)

= 1.4.3 =
* BUG: Now using the woocommerce_product_get_price filter instead of woocommerce_get_price.

= 1.4.2 =
* BUG: Fixed bug with loading our CSS. (Thanks, Hogash and VR51 on GitHub)

= 1.4.1 =
* BUG: Fixed typo in our add_action call so PMPro memberships are cancelled when the WooCommerce Subscriptions woocommerce_scheduled_subscription_end_of_prepaid_term hook fires.

= 1.4 =
* FEATURE: If the PMPro Gift Levels Addon is also active, adds settings to set a product to generate and email a gift certificate after purchase. (Thanks, Ted Barnett)
* BUG/FIX: Updated to fully support the new WooCommerce v2+ Subscriptions hooks for activation and cancelling. No longer supporting older versions of WC Subscriptions.
* BUG/FIX: Moved CSS load to proper WordPress action hook
* BUG/ENHANCEMENT: Configure proper text domain for translation
* BUG/ENHANCEMENT: Updated action hook for deprecated WooCommerce hooks
* ENHANCEMENT: Wrapping all strings for translation and using the proper text domain (pmpro-woocommerce) to support GlotPress translations.

= 1.3.1 =
* BUG: Fixed issue where products with blank membership pricing were being marked as free for members. Use "0", "0.00", or "0,00" to mark something as free. Use blank ("") to have a product use the main price or sale price.
* ENHANCEMENT: Made the wording of the member discount a bit more clear on the edit level page.

= 1.3 =
* FEATURE: Added a setting to the membership section of the edit product page with a checkbox to "mark the order as completed immediately after checkout to activate the associated membership".
* BUG: Fixed bug when setting membership price to 0.
* BUG: Fixed PHP notices on WooCommerce single product page when PMPro membership price discount was empty.
* BUG: Fixed issue where member prices were not being applied to products for members.

= 1.2.11 =
* BUG: Fixed bug where site would crash (PHP whitecreen) if Paid Memberships Pro was not active.

= 1.2.10 =
* BUG: Fixed bug when applying membership discounts to membership products and subscriptoins.
* BUG: Fixed warnings on edit membership level page.

= 1.2.9 =
* Hooking into scheduled_subscription_end_of_prepaid_term to cancel PMPro memberships for manually renewing WooCommerce Subscriptions when they hit expiration.

= 1.2.8 =
* Using current_time('timestamp') in a couple strtotime calls.
* Added links to docs and support in the "plugin row meta".

= 1.2.7 =
* Fixed bug where startdate was not being set correctly for new users. (Thanks, liferaft) This script can be used to fix startdates for old members: https://gist.github.com/strangerstudios/4604f62e9812cf3afde7

= 1.2.6 =
* Commented out filters on "woocommerce_order_status_pending" and "woocommerce_order_status_processing" hooks. This keeps PMPro from removing a user's membership level when they are renewing which can cause issues. (Thanks, Trisha Cupra and others.)

= 1.2.5.2 =
* Fixed bug with getting the expiration_number for levels with an X months expiration. (Thanks, Arnaud Devic)

= 1.2.5.1 =
* Fixed the pmprowoo_checkout_level_extend_memberships() filter added in 1.2.5.

= 1.2.5 =
* Now applying end date extension filter to woo commerce checkouts as well. So if an existing member purchases a product for their level that has an end date, their end date will be extended from the old end date. (Thanks, trishacupra)

= 1.2.4 =
* Fixed bug with WooCommerce Subscriptions being put "on hold".
* Fixed bug when entering a membership price > 1000.
* Fixed bug on some setups which set membership price to 0 if nothing was entered.

= 1.2.3 =
* Fixed bug when setting member price to "0" in product settings.

= 1.2.2 =
* Added option to "Apply Member Discounts to WC Subscription Products?" to the PMPro Advanced Settings tab.
* Fixed bug where membership discounts wouldn't be applied if no membership products were in the cart.
* WooCommerce now mimics PMPro checkout, creating a custom level array instead of passing the ID. So if your level has an expiration number and period, it will be used when adding the level to the user checking out in WooCommerce... i.e. expiration dates "work" now. You can filter the level information using the pmprowoo_checkout_level filter.
* Added pmprowoo_checkout_level filter to allow filtering the checkout level (to use PMPro expiration dates, etc. if Subscriptions addon is not installed)

= 1.2.1 =
* Fixed updating of WooCommerce billing address user meta when brand new users checkout with PMPro.

= 1.2 - 2014-04-23 =
* Updating user meta for billing address when the Woo Commerce billing address is updated and vice versa.

= 1.1.1 =
* Fixed fatal error that would be thrown if PMPro is not also activated.

= 1.1 =
* Fixed adding/updating membership when order status is changed to completed

= 1.0 - 2014-02-26 =
* Released to the WordPress repository.

= .3.2 =
* Fixed a bug where the get_price filter wasn't running when products/prices were loaded over AJAX (e.g. in the order review).
* Added code to force account creation at checkout if the cart includes a membership level.

= .3.1 =
* Fixed bug where products were erroneously counted as "subscription products" and thus discounts may not apply. You may have to edit these products and click "update" to get the settings to save correctly.

= .3 =
* Added membership products
* Added membership discounts
* Moved PMPro options to separate tab

= .2 =
* Added per level pricing to the edit product page. (Thanks, jessica o)

= .1 =
* This is the initial version of the plugin.

== Upgrade Notice ==

= 1.4 =
Fixes bugs related to the WooCommerce Subscriptions v2 update. Added support for translations. PLEASE NOTE that PMPro WooCommerce will no longer support older versions of WooCommerce Subscriptions. Make sure all plugins are up to date.
